# COMP23412 EventLite
## COMP23412 Software Engineering, University of Manchester, UK
### Robert Haines, Markel Vigo, Caroline Jay

*This is the skeleton lab code for the team-based exercise.*

See the instructions in Blackboard for more details.

#### Licence

BSD licenced, see Licence.md.
